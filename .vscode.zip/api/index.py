from flask import Flask, request, jsonify, render_template, redirect, url_for, flash
from flask_cors import CORS
import json
import os
import pandas as pd
from werkzeug.security import generate_password_hash, check_password_hash
from functools import wraps
from flask_sqlalchemy import SQLAlchemy

BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
app = Flask(__name__, static_folder=BASE_DIR, static_url_path='')
CORS(app)

app.config['SECRET_KEY'] = 'supersecretkey'

# Ensure the instance directory exists for SQLite
instance_dir = os.path.join(BASE_DIR, 'instance')
os.makedirs(instance_dir, exist_ok=True)

# Support production databases (PostgreSQL, MySQL, etc.) via environment variable
database_uri = os.environ.get('DATABASE_URL')
if database_uri:
    # PostgreSQL compatibility fix for SQLAlchemy (replace postgres:// with postgresql://)
    if database_uri.startswith("postgres://"):
        database_uri = database_uri.replace("postgres://", "postgresql://", 1)
else:
    # Fallback to local SQLite database with normalized path
    db_path = os.path.join(instance_dir, 'database.db').replace('\\', '/')
    database_uri = f'sqlite:///{db_path}'

app.config['SQLALCHEMY_DATABASE_URI'] = database_uri
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


def login_required(f):
    @wraps(f)
    def decorated_function(*args, **kwargs):
        # Placeholder for login required logic
        return f(*args, **kwargs)
    return decorated_function



# ── Helpers ──────────────────────────────────────────────────────

class questionset(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50))
    password = db.Column(db.String(20))
    date = db.Column(db.String(20))

class student_user(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    reg_id = db.Column(db.String(50), unique=True)
    dob = db.Column(db.String(100))
    student_name = db.Column(db.String(100))
    student_sem = db.Column(db.String(20))
    s_year = db.Column(db.String(20))

class AppUser(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True)
    password = db.Column(db.String(100))
    role = db.Column(db.String(20))

class QuizResult(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True)
    latestScore = db.Column(db.Integer, default=0)
    highScore = db.Column(db.Integer, default=0)
    totalTimeSpent = db.Column(db.Integer, default=0)
    lastLogin = db.Column(db.String(50), default="")
    correct = db.Column(db.Integer, default=0)
    wrong = db.Column(db.Integer, default=0)
    unanswered = db.Column(db.Integer, default=0)
    dailyTime = db.Column(db.JSON, default=dict)
    history = db.Column(db.JSON, default=list)

class QuizData(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    startTime = db.Column(db.String(50))
    endTime = db.Column(db.String(50))
    time = db.Column(db.Integer)
    questions = db.Column(db.JSON, default=list)

with app.app_context():
    db.create_all()




@app.route("/")
def serve_index():
    return app.send_static_file("index.html")


# ── Auth Routes ──────────────────────────────────────────────────

@app.route("/api/login", methods=["POST"])
def login():
    body = request.get_json()
    username = (body.get("username") or "").strip()
    password = (body.get("password") or "").strip()

    if not username:
        return jsonify({"error": "Username is required"}), 400

    # 1. Try to login from AppUser table (plaintext passwords for default / admin users)
    if password:
        user = AppUser.query.filter_by(username=username, password=password).first()
        if user:
            return jsonify({
                "message": "Login successful",
                "user": {
                    "username": user.username,
                    "role":     user.role
                }
            }), 200

    # 2. Try to login from student_user table (allow login with just username, or verify password if provided)
    student = student_user.query.filter_by(reg_id=username).first()
    if student:
        if not password or check_password_hash(student.dob, password):
            return jsonify({
                "message": "Login successful",
                "user": {
                    "username": student.reg_id,
                    "role":     "student"
                }
            }), 200

    return jsonify({"error": "Invalid username or password"}), 401


@app.route("/api/register", methods=["POST"])
def register():
    body     = request.get_json()
    username = (body.get("username") or "").strip()
    password = (body.get("password") or "").strip()
    role     = body.get("role", "student").strip()

    if not username or not password:
        return jsonify({"error": "Username and password are required"}), 400

    if role not in ("student", "admin"):
        return jsonify({"error": "Invalid role"}), 400

    if AppUser.query.filter_by(username=username).first():
        return jsonify({"error": "Username already exists"}), 409

    new_user = AppUser(username=username, password=password, role=role)
    db.session.add(new_user)
    db.session.commit()

    return jsonify({"message": "User created successfully"}), 201

# ── Quiz Routes ──────────────────────────────────────────────────

@app.route("/api/quiz", methods=["GET"])
def get_quiz():
    quiz = QuizData.query.first()
    if not quiz:
        return jsonify({"error": "Quiz data not found"}), 404
    data = {
        "startTime": quiz.startTime,
        "endTime": quiz.endTime,
        "time": quiz.time,
        "questions": quiz.questions
    }
    return jsonify(data), 200


@app.route("/api/quiz", methods=["POST"])
def save_quiz():
    """Admin: replace quiz data."""
    body = request.get_json()
    if not body:
        return jsonify({"error": "No data provided"}), 400
    
    quiz = QuizData.query.first()
    if not quiz:
        quiz = QuizData()
        db.session.add(quiz)
        
    quiz.startTime = body.get("startTime", "")
    quiz.endTime = body.get("endTime", "")
    quiz.time = body.get("time", 0)
    quiz.questions = body.get("questions", [])
    
    from sqlalchemy.orm.attributes import flag_modified
    flag_modified(quiz, "questions")
    
    db.session.commit()
    return jsonify({"message": "Quiz saved successfully"}), 200

@app.route("/api/quiz/upload-pdf", methods=["POST"])
def upload_pdf():
    if 'pdf' not in request.files:
        return jsonify({"error": "No file part"}), 400
    file = request.files['pdf']
    if file.filename == '':
        return jsonify({"error": "No selected file"}), 400
    
    if file and file.filename.lower().endswith('.pdf'):
        try:
            import pypdf
            reader = pypdf.PdfReader(file.stream)
            text = ""
            for page in reader.pages:
                extracted = page.extract_text()
                if extracted:
                    text += extracted + "\n\n"
            return jsonify({"text": text}), 200
        except ImportError:
            return jsonify({"error": "pypdf is not installed on the server"}), 500
        except Exception as e:
            return jsonify({"error": str(e)}), 500
    return jsonify({"error": "Invalid file type. Please upload a PDF."}), 400

# ── Results Routes ───────────────────────────────────────────────

@app.route("/api/results", methods=["GET"])
def get_results():
    results = QuizResult.query.all()
    result_dict = {r.username: r for r in results}
    
    # Get all students
    all_students = set()
    for u in AppUser.query.filter_by(role='student').all():
        all_students.add(u.username)
    for su in student_user.query.all():
        all_students.add(su.reg_id)
        
    for username in result_dict.keys():
        all_students.add(username)
        
    data = {"results": []}
    for username in all_students:
        r = result_dict.get(username)
        if r:
            data["results"].append({
                "username": r.username,
                "latestScore": r.latestScore,
                "highScore": r.highScore,
                "totalTimeSpent": r.totalTimeSpent,
                "lastLogin": r.lastLogin,
                "correct": r.correct,
                "wrong": r.wrong,
                "unanswered": r.unanswered,
                "dailyTime": r.dailyTime,
                "history": r.history
            })
        else:
            data["results"].append({
                "username": username,
                "latestScore": 0,
                "highScore": 0,
                "totalTimeSpent": 0,
                "lastLogin": "",
                "correct": 0,
                "wrong": 0,
                "unanswered": 0,
                "dailyTime": {},
                "history": []
            })
    return jsonify(data), 200


@app.route("/api/results", methods=["POST"])
def save_result():
    """Save / update a single user's quiz result, tracking history for multiple attempts."""
    body     = request.get_json()
    username = (body.get("username") or "").strip()

    if not username:
        return jsonify({"error": "Username is required"}), 400

    import datetime
    today_str = datetime.date.today().isoformat()
    date_time_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")

    time_spent = int(body.get("timeSpent") or 0)
    score_val = int(body.get("score") or 0)
    correct_val = int(body.get("correct") or 0)
    wrong_val = int(body.get("wrong") or 0)
    unans_val = int(body.get("unanswered") or 0)

    new_attempt = {
        "date": date_time_str,
        "score": score_val,
        "timeSpent": time_spent,
        "correct": correct_val,
        "wrong": wrong_val,
        "unanswered": unans_val
    }

    existing = QuizResult.query.filter_by(username=username).first()

    if existing:
        existing.latestScore = score_val
        existing.highScore = max(existing.highScore, score_val)
        existing.totalTimeSpent += time_spent
        existing.correct += correct_val
        existing.wrong += wrong_val
        existing.unanswered += unans_val
        existing.lastLogin = date_time_str
        
        # SQLAlchemy JSON columns require reassignment to trigger update
        history = list(existing.history) if existing.history else []
        history.append(new_attempt)
        existing.history = history
        
        daily_time = dict(existing.dailyTime) if existing.dailyTime else {}
        daily_time[today_str] = daily_time.get(today_str, 0) + time_spent
        existing.dailyTime = daily_time
        
        from sqlalchemy.orm.attributes import flag_modified
        flag_modified(existing, "history")
        flag_modified(existing, "dailyTime")
    else:
        new_result = QuizResult(
            username=username,
            latestScore=score_val,
            highScore=score_val,
            totalTimeSpent=time_spent,
            lastLogin=date_time_str,
            correct=correct_val,
            wrong=wrong_val,
            unanswered=unans_val,
            history=[new_attempt],
            dailyTime={today_str: time_spent}
        )
        db.session.add(new_result)

    db.session.commit()
    return jsonify({"message": "Result saved successfully"}), 200


@app.route("/api/results/<username>", methods=["GET"])
def get_user_result(username):
    r = QuizResult.query.filter_by(username=username).first()
    if not r:
        return jsonify({"error": "Result not found"}), 404
    
    record = {
        "username": r.username,
        "latestScore": r.latestScore,
        "highScore": r.highScore,
        "totalTimeSpent": r.totalTimeSpent,
        "lastLogin": r.lastLogin,
        "correct": r.correct,
        "wrong": r.wrong,
        "unanswered": r.unanswered,
        "dailyTime": r.dailyTime,
        "history": r.history
    }
    return jsonify(record), 200


@app.route("/api/results/<username>", methods=["DELETE"])
def delete_user_result(username):
    r = QuizResult.query.filter_by(username=username).first()
    if not r:
        return jsonify({"error": "User not found"}), 404
    db.session.delete(r)
    db.session.commit()
    return jsonify({"message": f"Result for {username} deleted"}), 200

# ── Users Routes (Admin) ─────────────────────────────────────────

@app.route("/api/users", methods=["GET"])
def get_users():
    users = AppUser.query.all()
    # Never expose passwords to the client
    safe  = [{"username": u.username, "role": u.role} for u in users]
    return jsonify({"users": safe}), 200


@app.route("/api/users/<username>", methods=["DELETE"])
def delete_user(username):
    user = AppUser.query.filter_by(username=username).first()
    if not user:
        return jsonify({"error": "User not found"}), 404
    db.session.delete(user)
    db.session.commit()
    return jsonify({"message": f"User {username} deleted"}), 200


@app.route("/bhuvi", methods=["GET","POST"])
@login_required  # Secure this so only logged-in admins can upload files
def import_users():
    if request.method == 'POST':
        # 1. Check if a file was actually uploaded
        if 'file' not in request.files:
            flash('No file part')
            return redirect(request.url)
            
        file = request.files['file']
        
        if file.filename == '':
            flash('No selected file')
            return redirect(request.url)

        if file:
            try:
                # 2. Read the file using Pandas (handles both CSV and Excel)
                if file.filename.endswith('.csv'):
                    df = pd.read_csv(file)
                elif file.filename.endswith(('.xls', '.xlsx')):
                    df = pd.read_excel(file)
                else:
                    flash('Invalid file format. Please upload a CSV or Excel file.')
                    return redirect(request.url)

                # 3. Loop through each row of the file and add to the database
                for index, row in df.iterrows():
                    username = str(row['reg_id']).strip()
                    plain_password = str(row['dob']).strip()
                    student_name = str(row['name']).strip()
                    student_sem = str(row['semester']).strip()
                    s_year = str(row['year']).strip()

                    
                    # Optional: Grab student info if you have columns for them
                    # location = str(row['location']).strip() if 'location' in row else None

                    # Check if the user already exists to avoid duplicates
                    existing_user = student_user.query.filter_by(reg_id=username).first()
                    if not existing_user:
                        # Hash the password securely before saving
                        hashed_pw = generate_password_hash(plain_password, method='pbkdf2:sha256')
                        
                        # Create new user (The ID is auto-assigned by the database)
                        new_user = student_user(reg_id=username, dob=hashed_pw, student_name=student_name, student_sem=student_sem, s_year=s_year)
                        db.session.add(new_user)

                # Save everything to the database at once
                db.session.commit()
                flash('File imported and users added successfully!')
                return redirect('/Admin/admin.html')

            except Exception as e:
                db.session.rollback()  # Undo changes if an error happens
                flash(f'An error occurred during import: {str(e)}')
                return redirect(request.url)

    return render_template('import.html')

# ── Health check ─────────────────────────────────────────────────

@app.route('/admin_dashboard')
def admin_dashboard():
    return "Admin Dashboard - Placeholder"

@app.route("/api/health", methods=["GET"])
def health():
    return jsonify({"status": "ok"}), 200

# ── Entry point ──────────────────────────────────────────────────

if __name__ == "__main__":
    print("[OK] Server running at http://127.0.0.1:5000")
    app.run(debug=True, port=5000)